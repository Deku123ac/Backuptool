@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_EXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
if not defined PYTHON_EXE (
  for /f "delims=" %%P in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do set "PYTHON_EXE=%%P"
)
if not defined PYTHON_EXE (
  for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)

if not defined PYTHON_EXE (
  echo Khong tim thay Python.
  echo Hay cai Python 3.12+ roi chay lai file nay.
  echo Neu may co winget, ban co the chay: winget install Python.Python.3.12
  pause
  exit /b 1
)

"%PYTHON_EXE%" -c "import customtkinter" >nul 2>nul
if errorlevel 1 (
  echo Dang cai thu vien customtkinter...
  "%PYTHON_EXE%" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Cai thu vien that bai. Hay kiem tra Internet hoac cai customtkinter thu cong.
    pause
    exit /b 1
  )
)

start "" "%PYTHON_EXE%" "%~dp0backup_tool_modern.py"
endlocal
