Lộc Phát Design - Backup Pro Source-Safe
========================================

Bản này không đóng gói EXE, dùng để tránh Windows Defender nghi nhầm file tự build.

Cách dùng:
1. Giải nén ZIP.
2. Mở Open_BackupToolPro.bat.
3. Chọn dữ liệu cần backup.
4. Chọn nơi lưu backup.
5. Chọn ngày bắt đầu, giờ backup và lịch cần chạy.
6. Bấm Cài lịch để Windows tự backup đúng giờ, hoặc Backup ngay để chạy liền.

Ghi chú cho máy mới:
- Nếu máy đã có Python và customtkinter, app sẽ mở ngay.
- Nếu thiếu customtkinter, launcher sẽ tự cài bằng pip.
- Nếu thiếu Python nhưng máy có winget, launcher sẽ tự cài Python 3.12 rồi mở app.
- Nếu máy không có winget hoặc không có Internet, hãy cài Python 3.12 trở lên rồi mở lại Open_BackupToolPro.bat.

Lưu ý:
- Cấu hình và log sẽ nằm cùng thư mục với file backup_tool_modern.py.
- Khi chỉnh sửa cấu hình cũ, bấm Hoàn tất sẽ ghi đè cấu hình đó, không tạo thêm dòng mới.
- Hoàn tất chỉ lưu cấu hình/lịch, không quét file và không tạo backup mới.
- Backup thật chỉ chạy khi bấm Backup ngay hoặc tới đúng giờ lịch Windows đã cài.
- Lịch Mỗi ngày có Ngày bắt đầu; Windows chỉ tự chạy từ ngày đó trở đi.
- Mặc định chỉ giữ 3 bản backup gần nhất để tránh đầy ổ.
- Bấm Kiểm tra, Backup ngay hoặc Cài lịch mới chạy kiểm tra sâu toàn bộ file.
- Giao diện chỉ hiển thị thống kê nhẹ để tránh bị đơ khi nguồn có hàng chục nghìn file.
- Khi backup, app copy từng file và cập nhật phần trăm liên tục, không còn đứng ở 0%.
- Launcher dùng pythonw để mở giao diện, không bật cửa sổ console đen.
- App tự bỏ qua folder kỹ thuật/cache như .venv, __pycache__, .git, node_modules để tránh lỗi path quá dài và không backup dữ liệu rác.
- Lịch Mỗi ngày không dùng checkbox ngày; checkbox chỉ dùng cho chế độ Tùy chọn ngày.
- Nếu đường dẫn bên trong ZIP quá dài khiến Windows Explorer dễ báo ZIP invalid, app sẽ tự giữ bản backup dạng folder đã verify thay vì tạo ZIP hỏng.
