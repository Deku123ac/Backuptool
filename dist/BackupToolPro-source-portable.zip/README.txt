Lộc Phát Design - Backup Pro Source-Safe
========================================

Bản này không đóng gói EXE, dùng để tránh Windows Defender nghi nhầm file tự build.

Cách dùng:
1. Giải nén ZIP.
2. Mở Open_BackupToolPro.bat.
3. Nếu máy đã có Python và customtkinter, app sẽ mở ngay.
4. Nếu thiếu customtkinter, launcher sẽ tự cài bằng pip.

Nếu máy chưa có Python:
- Cài Python 3.12 trở lên.
- Hoặc chạy: winget install Python.Python.3.12
- Sau đó mở lại Open_BackupToolPro.bat.

Lưu ý:
- Cấu hình và log sẽ nằm cùng thư mục với file backup_tool_modern.py.
- Khi chỉnh sửa cấu hình cũ, bấm Hoàn tất sẽ ghi đè cấu hình đó, không tạo thêm dòng mới.
- Hoàn tất chỉ lưu cấu hình/lịch, không quét file và không tạo backup mới.
- Backup thật chỉ chạy khi bấm Backup ngay hoặc tới đúng giờ lịch Windows đã cài.
- Bấm Kiểm tra, Backup ngay hoặc Cài lịch mới chạy kiểm tra sâu toàn bộ file.
- Giao diện chỉ hiển thị thống kê nhẹ để tránh bị đơ khi nguồn có hàng chục nghìn file.
- Khi backup, app copy từng file và cập nhật phần trăm liên tục, không còn đứng ở 0%.
- Launcher dùng pythonw để mở giao diện, không bật cửa sổ console đen.
- App tự bỏ qua folder kỹ thuật/cache như .venv, __pycache__, .git, node_modules để tránh lỗi path quá dài và không backup dữ liệu rác.
- Lịch Mỗi ngày không dùng checkbox ngày; checkbox chỉ dùng cho chế độ Tùy chọn ngày.
