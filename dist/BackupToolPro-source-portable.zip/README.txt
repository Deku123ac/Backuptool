Lộc Phát Design - Backup Pro Source-Safe
========================================

Bản này không đóng gói EXE, dùng để tránh Windows Defender nghi nhầm file tự build.

Cách dùng:
1. Giải nén ZIP.
2. Mở Open_BackupToolPro.bat.
3. Nếu máy đã có Python và customtkinter, app sẽ mở ngay.
4. Nếu thiếu customtkinter, launcher sẽ tự cài bằng pip.

Nếu máy chưa có Python:
- Cài Python 3.12 trở lên.
- Hoặc chạy: winget install Python.Python.3.12
- Sau đó mở lại Open_BackupToolPro.bat.

Lưu ý:
- Cấu hình và log sẽ nằm cùng thư mục với file backup_tool_modern.py.
- Khi chỉnh sửa cấu hình cũ, bấm Hoàn tất sẽ ghi đè cấu hình đó, không tạo thêm dòng mới.
- Bấm Kiểm tra, Backup ngay hoặc Cài lịch mới chạy kiểm tra sâu toàn bộ file.
- Giao diện chỉ hiển thị thống kê nhẹ để tránh bị đơ khi nguồn có hàng chục nghìn file.
