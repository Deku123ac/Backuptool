﻿Lộc Phát Design - Backup Pro
============================

Tiếng Việt
----------
- Tên app: Lộc Phát Design
- Có nút chọn ngôn ngữ: Tiếng Việt / English.
- Ngôn ngữ đã chọn sẽ được lưu lại cho lần mở sau.
- Tool backup có verify SHA-256 từng file, manifest và kiểm tra ZIP.

Cách dùng:
1. Giải nén ZIP vào folder có quyền ghi.
2. Mở BackupToolPro.exe.
3. Chọn ngôn ngữ nếu cần.
4. App mở ở trang Cấu hình đã lưu. Nếu đã có cấu hình cũ, tick chọn cấu hình rồi bấm Tải cấu hình này hoặc Chạy cấu hình này.
5. Nếu muốn tạo cấu hình mới, bấm Tạo cấu hình mới.
6. Bước Dữ liệu: thêm file/folder cần backup, rồi bấm Tiếp theo.
7. Bước Nơi lưu: chọn nơi lưu backup, rồi bấm Tiếp theo.
8. Bước Lịch: chọn lịch, ngày và giờ backup, rồi bấm Tiếp theo.
9. Bước Chạy backup: bấm Kiểm tra, Backup ngay hoặc Cài lịch.
10. Muốn Windows tự chạy theo lịch: bấm Cài lịch.
11. Muốn gỡ lịch tự động: bấm Gỡ lịch tự động ở thanh bên trái.
12. App tự lưu tối đa 20 cấu hình gần nhất để dùng lại nhanh.

Lưu ý an toàn:
- Nếu gặp lỗi Access is denied, hãy đóng phần mềm đang dùng file đó hoặc mở app bằng quyền Administrator.
- App không tự bỏ qua file lỗi, vì bỏ qua có thể làm backup thiếu dữ liệu.

English
-------
- App name: Lộc Phát Design
- Language switch: Tiếng Việt / English.
- The selected language is saved for next launch.
- Backups verify each file with SHA-256, include a manifest, and validate ZIP output.

How to use:
1. Extract the ZIP into a writable folder.
2. Open BackupToolPro.exe.
3. Choose language if needed.
4. The app opens on Saved configurations. If an old configuration exists, select it and click Load this config or Run this config.
5. To create a new configuration, click Create new config.
6. Data step: add files/folders to backup, then click Next.
7. Destination step: choose backup destination, then click Next.
8. Schedule step: choose schedule, day, and time, then click Next.
9. Run backup step: click Check, Run backup, or Install schedule.
10. To let Windows run backups automatically, click Install schedule.
11. To remove the automatic schedule, click Remove Schedule on the left sidebar.
12. The app keeps up to 20 recent configurations for quick reuse.

Safety note:
- If you see Access is denied, close the app using that file or run this tool as Administrator.
- The app does not silently skip failed files, because skipped files can mean incomplete backups.
