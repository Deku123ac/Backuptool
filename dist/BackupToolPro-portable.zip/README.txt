﻿Lộc Phát Design - Backup Pro
============================

Tiếng Việt
----------
- Tên app: Lộc Phát Design
- Có nút chọn ngôn ngữ: Tiếng Việt / English.
- Ngôn ngữ đã chọn sẽ được lưu lại cho lần mở sau.
- Tool backup có verify SHA-256 từng file, manifest và kiểm tra ZIP.

Cách dùng:
1. Giải nén ZIP vào folder có quyền ghi.
2. Mở BackupToolPro.exe.
3. Chọn ngôn ngữ nếu cần.
4. Thêm file/folder cần backup.
5. Chọn nơi lưu backup.
6. Bấm Kiểm tra, Backup ngay hoặc Cài lịch.

English
-------
- App name: Lộc Phát Design
- Language switch: Tiếng Việt / English.
- The selected language is saved for next launch.
- Backups verify each file with SHA-256, include a manifest, and validate ZIP output.

How to use:
1. Extract the ZIP into a writable folder.
2. Open BackupToolPro.exe.
3. Choose language if needed.
4. Add files/folders to backup.
5. Choose backup destination.
6. Click Check, Run backup, or Install schedule.
